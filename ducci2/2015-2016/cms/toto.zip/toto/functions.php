<?php

function toto_init_styles()
{
  wp_register_style(
    'mon-style',
    "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"
  );
  wp_enqueue_style('mon-style');

  wp_enqueue_script(
    'mon-jquery',
    'https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js',
    array(),
    false,
    true
  );
  wp_enqueue_script(
    'mon-script',
    'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js',
    array('mon-jquery'),
    false,
    true
  );
}
add_action('wp_enqueue_scripts', 'toto_init_styles');

function toto_setup_theme()
{
  add_editor_style();
  add_image_size( 'blog-thumb', 136, 126, true );
  add_theme_support( 'post-thumbnails' );
  load_theme_textdomain( 'toto', get_template_directory() . '/languages' );

  add_theme_support( 'menus' );
  register_nav_menu( "main", "Menu principal");
}
add_action('after_setup_theme', 'toto_setup_theme');
