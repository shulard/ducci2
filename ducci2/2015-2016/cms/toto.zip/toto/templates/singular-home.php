<div class="col-sm-6 col-md-4">
  <div class="thumbnail">
    <?php if( has_post_thumbnail() ): ?>
      <?php the_post_thumbnail(); ?>
    <?php endif; ?>
    <div class="caption">
      <h3><?php the_title(); ?></h3>
      <p><?php the_excerpt(); ?></p>
      <p>
        <a  href="<?php the_permalink(); ?>"
            class="btn btn-primary"
            role="button">
            <?php _e('Button', 'toto'); ?>
        </a>
      </p>
    </div>
  </div>
</div>
