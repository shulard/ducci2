<?php get_header(); ?>
    <h1><?php _e('Hello, world!', 'toto'); ?></h1>

    <?php if( have_posts() ): ?>
    <div class="row">
      <?php while( have_posts() ): the_post(); ?>
        <?php get_template_part('templates/singular', 'home'); ?>
      <?php endwhile; ?>
      <?php the_posts_pagination(); ?>
    </div>
    <?php endif; ?>

    <?php
      $query = new WP_Query(array(
        'post_type' => 'page'
      ));
    ?>

    <?php if( $query->have_posts() ): ?>
    <div class="row">
      <?php while( $query->have_posts() ): $query->the_post(); ?>
        <?php get_template_part('templates/singular', 'home'); ?>
      <?php endwhile; ?>
      <?php wp_reset_postdata(); ?>
    </div>
    <?php endif; ?>
<?php get_sidebar(); ?> 
<?php get_footer(); ?>
