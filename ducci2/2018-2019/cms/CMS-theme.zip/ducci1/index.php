<?php
    get_header();
?>

<!-- Section -->
<section>
    <header class="major">
        <h2><?= __('Ipsum sed dolor'); ?></h2>
    </header>
    <div class="posts"><?php
    if ( have_posts() ):
        while( have_posts() ): the_post();
            ?><article>
                <a href="<?= the_permalink(); ?>" class="image">
                    <?php if(has_post_thumbnail()): ?>
                    <img src="<?= the_post_thumbnail_url('list-thumb'); ?>" />
                    <?php else: ?>
                    <img src="<?= get_stylesheet_directory_uri(); ?>/images/pic01.jpg" alt="" />
                    <?php endif; ?>
                </a>
                <h3><?= the_title(); ?></h3>
                <?= the_excerpt(); ?>
                <ul class="actions">
                    <li>
                        <a href="<?= the_permalink(); ?>" class="button">
                            <?= __('More', 'ducci1'); ?>
                        </a>
                    </li>
                </ul>
            </article><?php
        endwhile;
    endif;
?>  </div>
</section><?php
    get_footer();
