<?php

add_action( 'after_setup_theme', function() {
    //Enhance theme support
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'menus' );

    register_nav_menu("main", __("Menu principal", 'ducci1'));

    register_sidebar(array(
        'name' => __('Sidebar principale', 'ducci1'),
        'id' => 'main-sidebar'
    ));

    //Register specific image sizes
    add_image_size( 'list-thumb', 416, 256, true );

    add_editor_style();
});

add_filter('image_size_names_choose', function(array $formats) {
    $formats['list-thumb'] = __('Miniature liste', 'ducci1');

    return $formats;
}, 10, 1);

add_action('wp_enqueue_scripts', function() {
    wp_register_script(
        'ducci1-html5shiv',
        get_stylesheet_directory_uri().'/assets/js/ie/html5shiv.js'
    );
    wp_script_add_data('ducci1-html5shiv','conditional','if lte IE 8');

    wp_register_style(
        'ducci1-main',
        get_stylesheet_directory_uri().'/assets/css/main.css'
    );
    wp_register_style(
        'ducci1-ie9',
        get_stylesheet_directory_uri().'/assets/css/ie9.css',
        ['ducci1-main']
    );
    wp_style_add_data('ducci1-ie9','conditional','if lte IE 9');
    wp_register_style(
        'ducci1-ie8',
        get_stylesheet_directory_uri().'/assets/css/ie8.css',
        ['ducci1-main']
    );
    wp_style_add_data('ducci1-ie8','conditional','if lte IE 8');

    wp_register_script(
        'ducci1-jquery',
        get_stylesheet_directory_uri().'/assets/js/jquery.min.js',
        [], false, true
    );
    wp_register_script(
        'ducci1-skel',
        get_stylesheet_directory_uri().'/assets/js/skel.min.js',
        ['ducci1-jquery'], false, true
    );
    wp_register_script(
        'ducci1-util',
        get_stylesheet_directory_uri().'/assets/js/util.js',
        ['ducci1-jquery'], false, true
    );
    wp_register_script(
        'ducci1-respond',
        get_stylesheet_directory_uri().'/assets/js/ie/respond.min.js',
        ['ducci1-jquery'], false, true
    );
    wp_script_add_data('ducci1-respond','conditional','if lte IE 8');
    wp_register_script(
        'ducci1-main',
        get_stylesheet_directory_uri().'/assets/js/main.js',
        ['ducci1-jquery'], false, true
    );

    wp_enqueue_script('ducci1-html5shiv');
    wp_enqueue_style('ducci1-main');
    wp_enqueue_style('ducci1-ie8');
    wp_enqueue_style('ducci1-ie9');

    wp_enqueue_script('ducci1-skel');
    wp_enqueue_script('ducci1-util');
    wp_enqueue_script('ducci1-respond');
    wp_enqueue_script('ducci1-main');
});
