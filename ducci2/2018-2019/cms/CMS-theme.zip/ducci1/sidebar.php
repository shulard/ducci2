<?php if( is_active_sidebar( 'main-sidebar' )  ): ?>
<!-- Sidebar -->
<div id="sidebar">
    <div class="inner">
        <?php dynamic_sidebar( 'main-sidebar' ); ?>
    </div>
</div>
<?php endif; ?>
